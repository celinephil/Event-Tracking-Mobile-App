package com.example.cs_3605_3projecttwo.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.cs_3605_3projecttwo.MainActivity;
import com.example.cs_3605_3projecttwo.Model.EventModel;
import com.example.cs_3605_3projecttwo.R;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private List<EventModel> eventList;
    private MainActivity activity;

    public EventAdapter(MainActivity activity){
        this.activity = activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_layout, parent, false);
        return new ViewHolder(itemView);
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        EventModel item = eventList.get(position);
        holder.event.setText(item.getEvent());
    }

    public int getItemCount(){
        return eventList.size();
    }

    private boolean toBoolean(int n){
        return n!=0;
    }

    public void setEvents(List<EventModel> eventList) {
        this.eventList = eventList;
        notifyDataSetChanged();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView event;

        ViewHolder(View view) {
            super(view);
            event = view.findViewById(R.id.options);
        }
    }
}
