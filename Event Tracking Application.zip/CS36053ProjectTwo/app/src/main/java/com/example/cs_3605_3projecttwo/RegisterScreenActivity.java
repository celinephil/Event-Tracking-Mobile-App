package com.example.cs_3605_3projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs_3605_3projecttwo.Database.DBHelper;

public class RegisterScreenActivity extends AppCompatActivity {

    EditText username, password, confirm_password;
    Button register_button;
    TextView existing_user;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_screen);

        // declaring and initializing functions
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        confirm_password = (EditText) findViewById(R.id.confirm_password);

        register_button = (Button) findViewById(R.id.register_button);
        existing_user = (TextView) findViewById(R.id.existing_user);
        DB = new DBHelper(this);

        // click event for the register button
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String confirmPass = confirm_password.getText().toString();

                // if else statement to check for empty fields
                if(user.equals("") || pass.equals("") || confirmPass.equals("")) {
                Toast.makeText(RegisterScreenActivity.this,"All Fields Required", Toast.LENGTH_SHORT).show(); }
                else {
                    if(pass.equals(confirmPass)) {
                        Boolean checkUser = DB.checkUsername(user);
                        if (checkUser == false) {
                            Boolean insert = DB.insertData(user, pass);
                            if (insert == true) {
                                Toast.makeText(RegisterScreenActivity.this, "Account created", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), LoginScreenActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(RegisterScreenActivity.this, "Failed to register", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(RegisterScreenActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(RegisterScreenActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // If account exists, send user to login screen
        existing_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginScreenActivity.class);
                startActivity(intent);
            }
        });
    }
}
