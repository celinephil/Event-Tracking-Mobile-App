package com.example.cs_3605_3projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.cs_3605_3projecttwo.Adapter.EventAdapter;
import com.example.cs_3605_3projecttwo.Database.DBHelper;
import com.example.cs_3605_3projecttwo.Model.EventModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private DBHelper db;
    private EventAdapter eventAdapter;
    private RecyclerView eventsRecyclerView;
    private FloatingActionButton addEvent;
    private List<EventModel> eventList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();

        eventList = new ArrayList<>();

        db = new DBHelper(this);

        // initialize variables and setting functions
        // eventsRecyclerView = (RecyclerView)findViewById(R.id.eventsRecyclerView);
        addEvent = (FloatingActionButton)findViewById(R.id.addEvent);
        eventAdapter = new EventAdapter(this);
        eventsRecyclerView.setAdapter(eventAdapter);
        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // testing event model
        EventModel event = new EventModel();
        event.setId(1);

        eventList.add(event);
        eventList.add(event);
        eventList.add(event);
        eventList.add(event);
        eventList.add(event);

        eventAdapter.setEvents(eventList);

        // set click listener for adding event button
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddEventScreen.class);
                startActivity(intent);            }
        });
    }
}
