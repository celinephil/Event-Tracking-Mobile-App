package com.example.cs_3605_3projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cs_3605_3projecttwo.Database.DBHelper;
import com.example.cs_3605_3projecttwo.Database.EventsDatabase;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import org.jetbrains.annotations.Nullable;

import java.util.Objects;


public class AddEventScreen extends BottomSheetDialogFragment {

    public static final String TAG = "ActionBottomDialog";

    EditText addEventTitle;
    EditText addEventDescription;
    EditText addEventDate;
    EditText addEventTime;
    Button createEventButton;
    ImageView returnButton;
    DBHelper DB;

    public static AddEventScreen newInstance(){
        return new AddEventScreen();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL, R.style.DialogStyle);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.new_event, container, false);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        return view;
    }

    // set title when create event button is clicked
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        addEventTitle = requireView().findViewById(R.id.addEventTitle);
        createEventButton = getView().findViewById(R.id.createEventButton);

    }
}