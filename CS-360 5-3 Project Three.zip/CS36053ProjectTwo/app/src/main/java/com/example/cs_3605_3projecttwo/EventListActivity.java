package com.example.cs_3605_3projecttwo;

import androidx.appcompat.app.AppCompatActivity;

public class EventListActivity extends AppCompatActivity {

}
