package com.example.cs_3605_3projecttwo.Model;

import androidx.room.ColumnInfo;
import androidx.room.PrimaryKey;

import java.io.Serializable;

public class EventModel implements Serializable {

    @PrimaryKey(autoGenerate = true)
    int eventId;
    @ColumnInfo(name = "eventTitle")
    String addEventTitle;
    @ColumnInfo(name = "date")
    String addEventDate;
    @ColumnInfo(name = "eventDescription")
    String addEventDescription;
    @ColumnInfo(name = "event")
    String addEvent;

    public EventModel() {

    }
    public int getId() {
        return eventId;
    }

    public void setId(int eventId) {
        this.eventId = eventId;
    }

    public String getTaskTitle() {
        return addEventTitle;
    }

    public void setTaskTitle(String addEventTitle) {
        this.addEventTitle = addEventTitle;
    }

    public String getDate() {
        return addEventDate;
    }

    public void setDate(String addEventDate) {
        this.addEventDate = addEventDate;
    }

    public String getTaskDescription() {
        return addEventDescription;
    }

    public void setTaskDescription(String addEventDescription) {
        this.addEventDescription = addEventDescription;
    }

    public String getEvent() {
        return addEvent;
    }

    public void setEvent(String addEvent) {
        this.addEvent = addEvent;
    }
}
