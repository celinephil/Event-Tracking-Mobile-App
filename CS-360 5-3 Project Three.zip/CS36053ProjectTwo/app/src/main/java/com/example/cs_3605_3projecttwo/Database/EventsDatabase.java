package com.example.cs_3605_3projecttwo.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.cs_3605_3projecttwo.Model.EventModel;

import java.util.ArrayList;
import java.util.List;

public class EventsDatabase extends SQLiteOpenHelper {

    public static final String EVENT_TABLE = "events";
    public static final String ID = "id";
    public static final String EVENT = "event";
    public static final String CREATE_EVENT_TABLE = "CREATE TABLE " + EVENT_TABLE + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + EVENT + " TEXT)";

    public EventsDatabase(Context context) {
        super(context, "EventsDatabase.db", null, 1);
    }

    private SQLiteDatabase db;


    // create table of events
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_EVENT_TABLE);
    }

    // drop table if event exists
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop older tables
        db.execSQL("drop Table if exists " + EVENT_TABLE);
        // create tables
        onCreate(db);
    }

    public void openDatabase() {
        db = this.getWritableDatabase();
    }

    //insert event function
    public void insertEvent(EventModel task){
        ContentValues cv = new ContentValues();
        cv.put(EVENT, task.getEvent());
        db.insert(EVENT_TABLE, null, cv);
    }

    // create event function
    public void createEvent(EventModel event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(EVENT, event.getEvent());
        db.insert(EVENT_TABLE, null, cv);
    }

    // update event function
    public void updateEvent(int id, String event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(EVENT, event);
        db.update(EVENT_TABLE, cv, ID + "= ?", new String[] {String.valueOf(id)});
    }

    // delete event function
    public void deleteEvent(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(EVENT_TABLE, ID + "= ?", new String[] {String.valueOf(id)});
    }
}
